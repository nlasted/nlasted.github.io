#!/bin/sh

python lasted.py